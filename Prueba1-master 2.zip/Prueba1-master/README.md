# Prueba1
Proyecto con TextViews en Android @emmanuel789
